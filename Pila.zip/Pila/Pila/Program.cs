﻿using System;
using System.Collections.Generic;

public class Pila<T>
{
    
    private List<T> elementos;

    
    public Pila()
    {
        // Inicialización del campo.
        this.elementos = new List<T>();
    }

    //-------------------------------------------------------------------------
    // Propiedades
    //-------------------------------------------------------------------------

    
    public int Count
    {
        get { return this.elementos.Count; }
    }

    
    public bool IsEmpty
    {
        get { return this.elementos.Count == 0; }
    }

    //-------------------------------------------------------------------------
    // Métodos (Operaciones de Pila)
    //-------------------------------------------------------------------------

    
    public void Push(T item)
    {
        this.elementos.Add(item);
    }

 
    public T Pop()
    {
        if (this.IsEmpty)
        {
            throw new InvalidOperationException("La pila está vacía. No se puede realizar la operación Pop.");
        }

        // 1. Determinar el índice de la cima (último elemento).
        int topIndex = this.elementos.Count - 1;

        // 2. Guardar el elemento que se va a extraer.
        T item = this.elementos[topIndex];

        // 3. Remover el elemento de la lista.
        this.elementos.RemoveAt(topIndex);

        return item;
    }

   
    public T Peek()
    {
        if (this.IsEmpty)
        {
            throw new InvalidOperationException("La pila está vacía. No se puede realizar la operación Peek.");
        }

        // Retorna el último elemento sin removerlo.
        return this.elementos[this.elementos.Count - 1];
    }

   
    public void Clear()
    {
        this.elementos.Clear();
    }
}